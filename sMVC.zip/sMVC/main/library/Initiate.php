<?php
define('ROOT', dirname(dirname(dirname(__FILE__))));
define('URLROOT', 'https://--your server url root--/-- pageName/companyName --');
define('IMGROOT', URLROOT.'/main/attached/img/');

require_once 'Base.php';
require_once 'main/attached/header.php';

$init = new Nav;


require_once 'main/attached/footer.php';