<?php

class Nav{
    protected $controller = 'page';
    protected $method = 'home';
    protected $params = [];
    
    function __construct(){
        $url = $this->getUrl();
        
        if(file_exists('main/controllers/'. ucwords($url[0]).'.php')){
           
            $this->controller = ucwords($url[0]);
            unset($url[0]);
            
        }
        
        require_once 'main/controllers/'.$this->controller.'.php';
       
        $this->controller = new $this->controller;
        
        //check for second part url
        
        if(isset($url[1])){
            //check to see if method exists in controller
            if(method_exists($this->controller, $url[1])){
                $this->method = $url[1];
                //unset 1 index
                unset($url[1]);
                
            }
        }
        
        //Get params
        $this->params = $url ? array_values($url) : [];
        
        //call a callback with array of params
        call_user_func_array([$this->controller, $this->method], $this->params);
                
        
    }
    
    function getUrl(){
         if(isset($_GET['url'])){
            
            $url = rtrim($_GET['url'], '/');
            $url = filter_var($url, FILTER_SANITIZE_URL);
            $url = explode('/', $url);
            return $url;
        }
    }
}

class Controller{
       
    // load view
    public function view($view, $data = []){
        // check for view file
        if(file_exists('main/views/'.$view.'.php')){
            require_once 'main/views/'.$view.'.php';
        }else{
            // view does not exist.
            die('View does not exist');
        }
    }
}
