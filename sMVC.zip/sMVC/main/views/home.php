
    <p class="vivify popInBottom delay-500"><?php echo $data['title']; ?></p>

     <img src="<?php echo IMGROOT.$data['imgName']; ?>">

