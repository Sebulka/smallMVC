<?php

class Page extends Controller{
    
    function home(){
        $data =[
            'title'=>'This is <i class="fas fa-home"></i> page title.',
            'imgName'=>'home.jpg'
        ];
        
        $this->view('/home', $data);
    }
    
    /*
    
     function --pageName--(){
        $data =[
            '--contentName--'=>'--Your content to display on page--',
            '--contentName2--'=>'--Your content2 to display on page--'
        ];
        
        $this->view('/--pageName--', $data);
    }
    
    */
}