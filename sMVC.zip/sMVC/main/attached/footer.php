<div id="footer">credits: 
Photo by Luke Stackpoole on Unsplash<br> https://unsplash.com/search/photos/house<br>
Brad Traversy, Traversy Media<br>
https://www.youtube.com/results?search_query=traversy+php+MVC</div>

</body>
</html>