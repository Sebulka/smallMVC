<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Title</title>
    <link href="<?php echo URLROOT ?>/main/attached/css/style.css" rel="stylesheet">
    <link href="<?php echo URLROOT ?>/main/attached/libraries/vivify.min.css" rel="stylesheet">
    <script src="<?php echo URLROOT ?>/main/attached/css/style.js"></script>
    <script src="<?php echo URLROOT ?>/main/attached/libraries/fontawesome-all.js"></script>
</head>
<body>
    
